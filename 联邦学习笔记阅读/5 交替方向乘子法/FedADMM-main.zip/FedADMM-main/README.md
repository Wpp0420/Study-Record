# FedADMM
This Matlab package was created based on the following paper

"Shenglong Zhou and Geoffrey Ye Li, Federated Learning via Inexact ADMM, [IEEE Transactions on Pattern Analysis and Machine Intelligence](https://ieeexplore.ieee.org/document/10040221), 2023"    

Please give credits to this paper if you use the code for your research.



