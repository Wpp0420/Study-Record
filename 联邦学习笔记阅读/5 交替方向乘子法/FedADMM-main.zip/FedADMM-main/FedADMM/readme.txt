To implement this solver, please 

run demonXXXX.m to solve different problems

This source code contains the algorithm described in:

"Shenglong Zhou and Geoffrey Ye Li, Federated Learning via Inexact ADMM, IEEE Transactions on Pattern Analysis and Machine Intelligence, 2023"    

Please give credits to this paper if you use the code for your research.
