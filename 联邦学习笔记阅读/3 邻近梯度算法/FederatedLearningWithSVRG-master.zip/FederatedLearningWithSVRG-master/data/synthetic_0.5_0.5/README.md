```
python generate_synthetic.py
```