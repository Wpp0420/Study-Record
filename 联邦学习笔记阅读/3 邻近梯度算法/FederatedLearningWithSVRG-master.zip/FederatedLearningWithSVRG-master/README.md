# Federated Learning with Proximal Stochastic Variance Reduced Gradient Algorithm (ICPP 2020)

This repository is for the Experiment Section of the paper: "Federated Learning with Proximal Stochastic Variance Reduced Gradient Algorithm"

This paper is processing in 49th International Conference on Parallel Processing - ICPP

Paper link: https://dl.acm.org/doi/10.1145/3404397.3404457

Authors:
Canh T.Dinh, Nguyen H. Tran, Tuan Dung Nguyen, Wei Bao, Albert Y. Zomaya, Bing B. Zhou


Our Code is developed based on the code from: 
https://github.com/litian96/FedProx

Presentation link:
https://www.youtube.com/watch?v=cXsFYcXF0KM
