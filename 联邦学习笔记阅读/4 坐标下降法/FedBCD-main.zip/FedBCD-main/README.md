# FedBCD
Federated Block Coordinate Descent (FedBCD) code for "Federated Block Coordinate Descent Scheme for Learning Global and Personalized Models", accepted by AAAI Conference on Artificial Intelligence 2021.
